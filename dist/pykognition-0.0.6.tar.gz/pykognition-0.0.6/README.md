# pykognition
Python wrapper for AWS Rekognition API
